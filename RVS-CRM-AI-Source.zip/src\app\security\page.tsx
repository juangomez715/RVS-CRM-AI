"use client";

import { Shield, ShieldCheck, ShieldAlert, Lock, Key, Activity, AlertTriangle, CheckCircle2, XCircle, Clock } from 'lucide-react';

export default function SecurityPage() {
    // Simulated audit log entries
    const auditLogs = [
        { id: '1', action: 'LOGIN_SUCCESS', userEmail: 'admin@rvs.com', ip: '192.168.1.10', details: 'Admin login from Chrome/Windows', createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString() },
        { id: '2', action: 'LOGIN_FAILED', userEmail: 'admin@rvs.com', ip: '45.33.22.11', details: 'Invalid password (attempt 3/5)', createdAt: new Date(Date.now() - 1000 * 60 * 20).toISOString() },
        { id: '3', action: 'LOGIN_FAILED', userEmail: 'admin@rvs.com', ip: '45.33.22.11', details: 'Invalid password (attempt 2/5)', createdAt: new Date(Date.now() - 1000 * 60 * 21).toISOString() },
        { id: '4', action: 'LOGIN_FAILED', userEmail: 'unknown@hacker.com', ip: '45.33.22.11', details: 'User not found', createdAt: new Date(Date.now() - 1000 * 60 * 22).toISOString() },
        { id: '5', action: 'RATE_LIMITED', userEmail: null, ip: '45.33.22.11', details: 'Blocked: 5 failed attempts in 15 min', createdAt: new Date(Date.now() - 1000 * 60 * 23).toISOString() },
        { id: '6', action: 'LOGIN_SUCCESS', userEmail: 'staff@rvs.com', ip: '192.168.1.15', details: 'Staff login from Firefox/Mac', createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString() },
        { id: '7', action: 'ADMIN_ACTION', userEmail: 'admin@rvs.com', ip: '192.168.1.10', details: 'Created new AI Agent: "Dental Outreach Bot"', createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString() },
        { id: '8', action: 'LOGOUT', userEmail: 'staff@rvs.com', ip: '192.168.1.15', details: 'Manual logout', createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8).toISOString() },
    ];

    const securityLayers = [
        { name: 'JWT Signed Sessions', status: 'active', icon: Key, description: 'Cryptographic token prevents cookie tampering' },
        { name: 'Brute Force Shield', status: 'active', icon: ShieldAlert, description: 'Max 5 login attempts per IP / 15 min window' },
        { name: 'OWASP Headers', status: 'active', icon: Lock, description: 'XSS, Clickjack, HSTS, CSP protections enabled' },
        { name: 'API Authentication', status: 'active', icon: ShieldCheck, description: 'All API endpoints require valid JWT' },
        { name: 'Audit Trail', status: 'active', icon: Activity, description: 'Every login, action, and failure is logged' },
    ];

    const formatTime = (dateStr: string) => {
        return new Intl.DateTimeFormat('en-US', {
            month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', second: '2-digit'
        }).format(new Date(dateStr));
    };

    const getActionBadge = (action: string) => {
        switch (action) {
            case 'LOGIN_SUCCESS':
                return { color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20', icon: <CheckCircle2 size={12} />, label: 'Login OK' };
            case 'LOGIN_FAILED':
                return { color: 'text-orange-400 bg-orange-500/10 border-orange-500/20', icon: <XCircle size={12} />, label: 'Failed Login' };
            case 'RATE_LIMITED':
                return { color: 'text-rose-500 bg-rose-500/10 border-rose-500/20', icon: <ShieldAlert size={12} />, label: 'Rate Limited' };
            case 'ADMIN_ACTION':
                return { color: 'text-blue-400 bg-blue-500/10 border-blue-500/20', icon: <Key size={12} />, label: 'Admin' };
            case 'LOGOUT':
                return { color: 'text-rvs-steel bg-rvs-steel/10 border-rvs-steel/20', icon: <Lock size={12} />, label: 'Logout' };
            default:
                return { color: 'text-rvs-steel bg-rvs-steel/10 border-rvs-steel/20', icon: <Activity size={12} />, label: action };
        }
    };

    const failedCount = auditLogs.filter(l => l.action === 'LOGIN_FAILED' || l.action === 'RATE_LIMITED').length;
    const successCount = auditLogs.filter(l => l.action === 'LOGIN_SUCCESS').length;

    return (
        <div className="p-8 h-full bg-[#0A0A0A] overflow-y-auto">
            <div className="flex justify-between items-end mb-8 border-b border-rvs-steel/20 pb-4">
                <div>
                    <h1 className="text-3xl font-black text-white tracking-widest uppercase flex items-center gap-3">
                        <Shield className="text-rvs-red-light" size={32} /> Security Center
                    </h1>
                    <p className="text-rvs-steel text-sm font-bold uppercase tracking-widest mt-2">
                        Cybersecurity Layers & Audit Trail
                    </p>
                </div>
                <div className="flex gap-3">
                    <div className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-lg">
                        <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Protection</p>
                        <p className="text-emerald-400 font-black text-lg">5 / 5</p>
                    </div>
                    <div className="bg-rose-500/10 border border-rose-500/20 px-4 py-2 rounded-lg">
                        <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Threats Blocked</p>
                        <p className="text-rose-400 font-black text-lg">{failedCount}</p>
                    </div>
                </div>
            </div>

            {/* Security Layers Status */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-8">
                {securityLayers.map((layer, idx) => (
                    <div key={idx} className="bg-rvs-darker border border-emerald-500/20 rounded-lg p-4 text-center group hover:border-emerald-500/50 transition-all">
                        <div className="flex justify-center mb-2">
                            <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                                <layer.icon className="text-emerald-400" size={18} />
                            </div>
                        </div>
                        <p className="text-white font-black text-xs tracking-widest uppercase mb-1">{layer.name}</p>
                        <p className="text-[10px] text-rvs-steel">{layer.description}</p>
                        <div className="mt-2">
                            <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest border border-emerald-500/30 px-2 py-0.5 rounded-full">Active</span>
                        </div>
                    </div>
                ))}
            </div>

            {/* Audit Log Table */}
            <div className="bg-rvs-darker border border-rvs-steel/20 rounded-xl overflow-hidden">
                <div className="p-5 border-b border-rvs-steel/10 flex justify-between items-center">
                    <h2 className="text-white font-black tracking-widest uppercase text-sm flex items-center gap-2">
                        <Activity size={16} className="text-rvs-red-light" /> Live Audit Trail
                    </h2>
                    <span className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">{auditLogs.length} events</span>
                </div>

                <div className="divide-y divide-rvs-steel/5">
                    {auditLogs.map(log => {
                        const badge = getActionBadge(log.action);
                        return (
                            <div key={log.id} className="flex items-center gap-4 px-5 py-3 hover:bg-rvs-dark/30 transition-all">
                                <div className={`flex items-center gap-1.5 px-2 py-1 rounded border text-[10px] font-bold uppercase tracking-widest whitespace-nowrap ${badge.color}`}>
                                    {badge.icon} {badge.label}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm text-white truncate">{log.details}</p>
                                </div>
                                <div className="text-xs text-rvs-chrome/60 font-mono whitespace-nowrap">
                                    {log.userEmail || '—'}
                                </div>
                                <div className="text-xs text-rvs-steel font-mono whitespace-nowrap">
                                    {log.ip}
                                </div>
                                <div className="text-xs text-rvs-steel/50 font-mono whitespace-nowrap flex items-center gap-1">
                                    <Clock size={10} /> {formatTime(log.createdAt)}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

export async function PATCH(
    request: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const data = await request.json();
        const { name, goal, isActive, steps } = data;

        // 1. Update sequence metadata if provided
        await prisma.sequence.update({
            where: { id },
            data: { 
                name, 
                goal, 
                isActive 
            }
        });

        // 2. If steps are provided, we do a sync (delete old, create new to keep it simple for this MVP)
        if (steps && Array.isArray(steps)) {
            await prisma.sequenceStep.deleteMany({ where: { sequenceId: id } });
            
            if (steps.length > 0) {
                await prisma.sequenceStep.createMany({
                    data: steps.map((s: any) => ({
                        sequenceId: id,
                        dayOffset: Number(s.dayOffset),
                        subject: s.subject,
                        content: s.content || '',
                        isAIGenerated: s.isAIGenerated || false
                    }))
                });
            }
        }

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Sequence Update Error:", error);
        return NextResponse.json({ error: "Failed to update sequence" }, { status: 500 });
    }
}

export async function DELETE(
    request: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        await prisma.sequence.delete({ where: { id } });
        return NextResponse.json({ success: true });
    } catch (error) {
        return NextResponse.json({ error: "Failed to delete sequence" }, { status: 500 });
    }
}

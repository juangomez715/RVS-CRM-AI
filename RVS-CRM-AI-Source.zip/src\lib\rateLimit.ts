/**
 * In-memory rate limiter for brute force protection.
 * Tracks failed login attempts per IP address.
 * Max 5 attempts in a 15-minute window.
 */

interface RateLimitEntry {
    count: number;
    firstAttempt: number;
}

const loginAttempts = new Map<string, RateLimitEntry>();
const MAX_ATTEMPTS = 5;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes

/**
 * Checks if an IP is rate limited.
 * Returns { allowed: boolean, retryAfterMs: number }
 */
export function checkRateLimit(ip: string): { allowed: boolean; retryAfterMs: number } {
    const now = Date.now();
    const entry = loginAttempts.get(ip);

    if (!entry) {
        return { allowed: true, retryAfterMs: 0 };
    }

    // If the window has expired, reset
    if (now - entry.firstAttempt > WINDOW_MS) {
        loginAttempts.delete(ip);
        return { allowed: true, retryAfterMs: 0 };
    }

    if (entry.count >= MAX_ATTEMPTS) {
        const retryAfterMs = WINDOW_MS - (now - entry.firstAttempt);
        return { allowed: false, retryAfterMs };
    }

    return { allowed: true, retryAfterMs: 0 };
}

/**
 * Records a failed login attempt for a given IP.
 */
export function recordFailedAttempt(ip: string): void {
    const now = Date.now();
    const entry = loginAttempts.get(ip);

    if (!entry || now - entry.firstAttempt > WINDOW_MS) {
        loginAttempts.set(ip, { count: 1, firstAttempt: now });
    } else {
        entry.count++;
    }
}

/**
 * Clears the rate limit for a given IP (on successful login).
 */
export function clearRateLimit(ip: string): void {
    loginAttempts.delete(ip);
}

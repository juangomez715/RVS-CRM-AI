import prisma from '@/lib/db';
import { sendEmailWithShield } from '@/lib/mailer';
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
    try {
        const { leadId, subject = 'Conversation Update', content } = await request.json();

        if (!leadId || !content) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const lead = await prisma.lead.findUnique({ where: { id: leadId } });

        if (!lead || !lead.email) {
            return NextResponse.json({ error: "Lead email is missing or lead not found" }, { status: 404 });
        }

        // 1. Send via Real Mailer Shield (SMTP)
        const sent = await sendEmailWithShield(lead.email, subject, content);

        if (!sent.success) {
            return NextResponse.json({ error: "SMTP Transport failed" }, { status: 500 });
        }

        // 2. Save Human Interaction locally
        const newInteraction = await prisma.interaction.create({
            data: {
                leadId,
                channel: 'Email',
                sender: 'HUMAN',
                content: `Sub: ${subject}\n\n${content}`,
                repliedAt: new Date()
            }
        });

        // Map for frontend parsing
        return NextResponse.json({
            id: newInteraction.id,
            channel: newInteraction.channel,
            sender: newInteraction.sender,
            content: newInteraction.content,
            createdAt: new Date(newInteraction.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });

    } catch (error: any) {
        console.error("Manual Send Error:", error.message);
        return NextResponse.json({ error: error.message || "Failed to transmit message" }, { status: 500 });
    }
}

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';

export interface OllamaResponse {
    model: string;
    created_at: string;
    response: string;
    done: boolean;
}

export async function generateAIResponse(prompt: string, model: string = 'qwen3.5:0.8b'): Promise<string> {
    try {
        const res = await fetch(`${OLLAMA_URL}/api/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model,
                prompt,
                stream: false,
            }),
        });

        if (!res.ok) {
            throw new Error(`Failed to connect to Ollama: ${res.statusText}`);
        }

        const data: OllamaResponse = await res.json();
        return data.response;
    } catch (error) {
        console.error("AI Generation Error:", error);
        return "Error: Could not reach the local AI engine. Make sure Ollama is running and the model is pulled.";
    }
}
export async function qualifyLead(message: string): Promise<{ score: number; reasoning: string }> {
    const prompt = `You are an expert Lead Qualifier for RVS CRM (a dental medical sales company). 
Analyze the following lead message and provide:
1. A qualification score from 0 to 100 (High score = strong intent to buy/schedule).
2. A very brief reasoning (10 words max).

Lead Message: "${message}"

Respond strictly in JSON format like this:
{"score": 85, "reasoning": "Strong interest in pricing and scheduling."}`;

    try {
        const rawResponse = await generateAIResponse(prompt);
        // Try to extract JSON from the response
        const jsonMatch = rawResponse.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        }
        return { score: 0, reasoning: "Could not parse AI response." };
    } catch (error) {
        return { score: 0, reasoning: "AI Error during qualification." };
    }
}

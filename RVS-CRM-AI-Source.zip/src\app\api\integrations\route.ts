import prisma from '@/lib/db';
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { jwtVerify } from 'jose';

const JWT_SECRET = new TextEncoder().encode(
    process.env.JWT_SECRET || 'rvs-crm-secret-key-change-in-production-2026'
);

export async function GET(request: Request) {
    // Basic auth check
    const sessionCookie = (await cookies()).get('rvs_session');
    if (!sessionCookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    try {
        const integrations = await prisma.integration.findMany();
        return NextResponse.json(integrations);
    } catch (error) {
        return NextResponse.json({ error: 'Failed to fetch integrations' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    const sessionCookie = (await cookies()).get('rvs_session');
    if (!sessionCookie) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    try {
        const data = await request.json();

        // Upsert based on provider
        const integration = await prisma.integration.findFirst({
            where: { provider: data.provider }
        });

        if (integration) {
            const updated = await prisma.integration.update({
                where: { id: integration.id },
                data: {
                    isActive: data.isActive !== undefined ? data.isActive : integration.isActive,
                    accountId: data.accountId || integration.accountId,
                    metadata: data.metadata || integration.metadata
                }
            });
            return NextResponse.json(updated);
        } else {
            const created = await prisma.integration.create({
                data: {
                    provider: data.provider,
                    isActive: data.isActive !== undefined ? data.isActive : true,
                    accountId: data.accountId,
                    metadata: data.metadata
                }
            });
            return NextResponse.json(created);
        }
    } catch (error) {
        console.error(error);
        return NextResponse.json({ error: 'Failed to save integration' }, { status: 500 });
    }
}

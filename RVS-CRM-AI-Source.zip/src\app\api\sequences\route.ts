import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

// GET all sequences with step counts and lead counts
export async function GET() {
    try {
        const sequences = await prisma.sequence.findMany({
            include: {
                _count: {
                    select: { steps: true, leads: true }
                },
                steps: {
                    orderBy: { dayOffset: 'asc' }
                }
            },
            orderBy: { createdAt: 'desc' }
        });
        return NextResponse.json(sequences);
    } catch (error) {
        return NextResponse.json({ error: "Failed to load sequences" }, { status: 500 });
    }
}

// POST create a new sequence
export async function POST(request: Request) {
    try {
        const { name, goal } = await request.json();
        const sequence = await prisma.sequence.create({
            data: { name, goal, isActive: true },
            include: { steps: true, _count: { select: { steps: true, leads: true } } }
        });
        return NextResponse.json(sequence);
    } catch (error) {
        return NextResponse.json({ error: "Failed to create sequence" }, { status: 500 });
    }
}

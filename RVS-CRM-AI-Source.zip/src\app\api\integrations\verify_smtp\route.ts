import { NextResponse } from 'next/server';
import nodemailer from 'nodemailer';
import prisma from '@/lib/db';

export async function POST(request: Request) {
    try {
        const data = await request.json();
        const { host, port, secure, username, password } = data;

        if (!host || !port || !username || !password) {
            return NextResponse.json({ error: "Missing required SMTP fields" }, { status: 400 });
        }

        const transporter = nodemailer.createTransport({
            host: host,
            port: Number(port),
            secure: secure, // true for 465, false for other ports
            auth: {
                user: username,
                pass: password,
            },
        });

        // Verify connection configuration
        await transporter.verify();

        // If it passes, save the configuration to the database
        const metadata = {
            host, port: Number(port), secure, username, password,
            dailyLimit: 150, delayMin: 3, delayMax: 7, warmingActive: true
        };

        // Upsert the 'smtp' integration
        const existing = await prisma.integration.findFirst({ where: { provider: 'smtp' } });

        let saved;
        if (existing) {
            saved = await prisma.integration.update({
                where: { id: existing.id },
                data: {
                    isActive: true,
                    accountId: username,
                    metadata: JSON.stringify(metadata)
                }
            });
        } else {
            saved = await prisma.integration.create({
                data: {
                    provider: 'smtp',
                    isActive: true,
                    accountId: username,
                    metadata: JSON.stringify(metadata)
                }
            });
        }

        return NextResponse.json({ success: true, message: "SMTP configuration verified and saved." });

    } catch (error: any) {
        console.error("SMTP Verification Error:", error.message);
        return NextResponse.json({
            error: "Authentication failed. Check your credentials, App Passwords, or Host settings."
        }, { status: 401 });
    }
}

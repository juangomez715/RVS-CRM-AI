import prisma from '@/lib/db';
import { generateAIResponse } from '@/lib/ai';
import { sendEmailWithShield } from '@/lib/mailer';
import { NextResponse } from 'next/server';

/**
 * AI ENGINES: SEQUENCE RUNNER
 * Can be triggered by a Cron Job, Vercel standard cron, or n8n HTTP node
 * Searches for all active lead sequences, calculates offsets, and executes if it's time.
 */

export async function POST(request: Request) {
    // 1. Authenticate ping
    const authHeader = request.headers.get('authorization');
    if (authHeader !== `Bearer ${process.env.CRON_SECRET || 'rvs-cron-secret'}`) {
        return NextResponse.json({ error: 'Unauthorized CRON ping' }, { status: 401 });
    }

    try {
        console.log("[Engine Cron] Initiating Sequence Run...");

        // Find sequences currently active
        const activeSequences = await prisma.leadSequence.findMany({
            where: { status: 'ACTIVE' },
            include: {
                lead: true,
                sequence: {
                    include: { steps: { orderBy: { dayOffset: 'asc' } } }
                }
            }
        });

        const results = [];

        for (const ls of activeSequences) {
            // How many days have passed since enroll?
            // Local dev offset logic for quick testing
            const enrolledAtMs = new Date(ls.enrolledAt).getTime();
            const now = Date.now();
            const daysSinceEnroll = Math.floor((now - enrolledAtMs) / (1000 * 60 * 60 * 24));

            // Find the step they SHOULD be on based on dayOffset
            const targetStep = ls.sequence.steps.find((s, index) => {
                // If this step is for today OR later AND they haven't executed it
                return s.dayOffset <= daysSinceEnroll && index >= ls.currentStep;
            });

            if (targetStep) {
                // Execute Step!
                try {
                    let finalSubject = targetStep.subject;
                    let finalBody = targetStep.content;

                    // IF isAIGenerated -> We must use the AI Copilot to rewrite the email
                    if (targetStep.isAIGenerated) {
                        // Find active Agent to rewrite
                        const activeAgent = await prisma.agent.findFirst({ where: { isActive: true } });
                        if (activeAgent) {
                            const systemContext = `
                                ${activeAgent.systemPrompt}
                                \n[Knowledge Base]:\n${activeAgent.knowledgeBase || 'None'}
                                \n[LEAD DATA]: Name: ${ls.lead.name}, Company: ${ls.lead.company || 'Unknown'}, Notes: ${ls.lead.aiNotes || ''}
                            `;
                            const instruction = `Draft an email subject and body based on this template goal: Subject: ${targetStep.subject}\nBody: ${targetStep.content}\nMake it sound natural and follow the tone. Respond ALWAYS in valid JSON format: {"subject": "...", "body": "..."}`;

                            const aiDraftStr = await generateAIResponse(instruction, activeAgent.llmModel);
                            try {
                                const aiDraft = JSON.parse(aiDraftStr);
                                finalSubject = aiDraft.subject || finalSubject;
                                finalBody = aiDraft.body || finalBody;
                            } catch (e) {
                                // Fallback to raw AI string if it failed JSON schema
                                finalBody = aiDraftStr;
                            }
                        }
                    } else {
                        // Replace simple dynamic tags manually
                        finalSubject = finalSubject.replace('{{name}}', ls.lead.name).replace('{{company}}', ls.lead.company || '');
                        finalBody = finalBody.replace('{{name}}', ls.lead.name).replace('{{company}}', ls.lead.company || '');
                    }

                    // 4. Send via Deliverability Shield
                    // Creates an Interaction DB entry FIRST to grab a trackingId
                    const interaction = await prisma.interaction.create({
                        data: {
                            leadId: ls.lead.id,
                            channel: 'Email',
                            sender: 'AI_AUTOMATION',
                            content: `Subject: ${finalSubject}\n\n${finalBody}`,
                            // trackingId autofills via default(cuid())
                        }
                    });

                    await sendEmailWithShield(ls.lead.email || '', finalSubject, finalBody, interaction.trackingId || undefined);

                    // Update sequence step
                    const updatedSequence = await prisma.leadSequence.update({
                        where: { id: ls.id },
                        data: {
                            currentStep: ls.sequence.steps.findIndex(s => s.id === targetStep.id) + 1,
                            lastExecutedAt: new Date()
                        }
                    });

                    results.push({ leadId: ls.lead.id, stepExecuted: targetStep.id, success: true });
                } catch (e: any) {
                    console.error("[Sequence Run Error for Lead]", ls.lead.id, e.message);
                    results.push({ leadId: ls.lead.id, stepExecuted: targetStep.id, success: false, error: e.message });
                }
            }
        }

        return NextResponse.json({ success: true, executed: results });

    } catch (error) {
        console.error("Cron Error", error);
        return NextResponse.json({ error: 'Failed Engine Execution' }, { status: 500 });
    }
}

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    const adminPassword = await bcrypt.hash('admin123', 10);
    const staffPassword = await bcrypt.hash('staff123', 10);

    await prisma.user.upsert({
        where: { email: 'admin@rvs.com' },
        update: {},
        create: {
            email: 'admin@rvs.com',
            name: 'Admin',
            password: adminPassword,
            role: 'ADMIN',
        },
    });

    await prisma.user.upsert({
        where: { email: 'staff@rvs.com' },
        update: {},
        create: {
            email: 'staff@rvs.com',
            name: 'Staff Member',
            password: staffPassword,
            role: 'STAFF',
        },
    });

    console.log('Seed completed: admin@rvs.com and staff@rvs.com created.');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });

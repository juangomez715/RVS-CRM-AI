import prisma from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
    try {
        const leads = await prisma.lead.findMany({
            where: {
                interactions: { some: {} } // Only fetch leads that have at least one message
            },
            include: {
                interactions: {
                    orderBy: { createdAt: 'asc' }
                }
            },
            orderBy: { createdAt: 'desc' }
        });

        // Map them nicely for the frontend
        const mappedLeads = leads.map(l => ({
            id: l.id,
            name: l.name,
            company: l.company || 'Unknown',
            email: l.email,
            aiStatus: l.aiStatus,
            interactions: l.interactions.map(int => ({
                id: int.id,
                channel: int.channel,
                sender: int.sender,
                content: int.content,
                createdAt: new Date(int.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }))
        }));

        return NextResponse.json(mappedLeads);
    } catch (error) {
        console.error("Failed to load inbox", error);
        return NextResponse.json({ error: "Failed to load inbox data" }, { status: 500 });
    }
}

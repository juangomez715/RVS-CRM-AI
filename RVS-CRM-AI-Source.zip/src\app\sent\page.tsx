"use client";
import { useState } from 'react';
import { Mail, CheckCheck, Check, MousePointerClick, CalendarDays, Reply, AlertTriangle, ShieldX } from 'lucide-react';

export default function SentBoxPage() {
    // Dummy data representing messages sent by Staff or AI
    const sentMessages = [
        {
            id: '1',
            leadName: 'Dr. Sarah Jenkins',
            to: 'sarah@smileclinic.com',
            subject: 'Aligner Overview - Quick chat?',
            content: 'Hi Sarah, would you be open to a 5 min overview of our new aligners?',
            sentAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
            readAt: new Date(Date.now() - 1000 * 60 * 60 * 1).toISOString(), // 1 hour ago
            clickedAt: null,
            repliedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 mins ago
            bouncedAt: null,
            spamAt: null,
            sender: 'AI'
        },
        {
            id: '2',
            leadName: 'Mark Roberts',
            to: 'm.roberts@pristinedental.com',
            subject: 'Pricing sheet as requested',
            content: 'Hello Mark, Attached is the PDF with the 2026 pricing. Let me know if you want to jump on a call.',
            sentAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
            readAt: new Date(Date.now() - 1000 * 60 * 60 * 20).toISOString(),
            clickedAt: new Date(Date.now() - 1000 * 60 * 60 * 19).toISOString(), // Clicked the link
            repliedAt: null,
            bouncedAt: null,
            spamAt: null,
            sender: 'HUMAN'
        },
        {
            id: '3',
            leadName: 'Jessica Tran',
            to: 'jtran@orthocare.net',
            subject: 'Checking in',
            content: 'Jessica, just bumping this to the top of your inbox.',
            sentAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(), // 15 mins ago
            readAt: null,
            clickedAt: null,
            repliedAt: null,
            bouncedAt: new Date(Date.now() - 1000 * 60 * 14).toISOString(), // Bounce right away
            spamAt: null,
            sender: 'HUMAN'
        },
        {
            id: '4',
            leadName: 'William Chen',
            to: 'w.chen@healthcare.io',
            subject: 'Automated outreach',
            content: 'Hi William, let me know if you want to talk about our new CRM plan.',
            sentAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), // 5 hours ago
            readAt: null,
            clickedAt: null,
            repliedAt: null,
            bouncedAt: null,
            spamAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(), // Spam blocked
            sender: 'AI'
        }
    ];

    const formatDate = (dateString: string | null) => {
        if (!dateString) return 'Never';
        return new Intl.DateTimeFormat('en-US', {
            month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
        }).format(new Date(dateString));
    };

    return (
        <div className="p-8 h-full bg-[#0A0A0A] overflow-y-auto">
            <div className="flex justify-between items-end mb-8 border-b border-rvs-steel/20 pb-4">
                <div>
                    <h1 className="text-3xl font-black text-white tracking-widest uppercase items-center flex gap-3">
                        <Mail className="text-rvs-red-light" size={32} /> OUTBOX
                    </h1>
                    <p className="text-rvs-steel text-sm font-bold uppercase tracking-widest mt-2">
                        Email Tracking & Delivery Stats
                    </p>
                </div>

                <div className="flex gap-4">
                    {/* Mini Stats */}
                    <div className="bg-rvs-darker border border-rvs-steel/20 p-3 rounded-lg flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-blue-500/10 flex items-center justify-center">
                            <CheckCheck className="text-blue-400" size={16} />
                        </div>
                        <div>
                            <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Open Rate</p>
                            <p className="text-white font-black">66%</p>
                        </div>
                    </div>

                    <div className="bg-rvs-darker border border-rvs-steel/20 p-3 rounded-lg flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-rvs-red-dark/20 flex items-center justify-center">
                            <MousePointerClick className="text-rvs-red-light" size={16} />
                        </div>
                        <div>
                            <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Click Rate</p>
                            <p className="text-white font-black">33%</p>
                        </div>
                    </div>

                    <div className="bg-rvs-darker border border-rvs-steel/20 p-3 rounded-lg flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-emerald-500/10 flex items-center justify-center">
                            <Reply className="text-emerald-400" size={16} />
                        </div>
                        <div>
                            <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Reply Rate</p>
                            <p className="text-white font-black">25%</p>
                        </div>
                    </div>

                    <div className="bg-rvs-darker border border-rvs-steel/20 p-3 rounded-lg flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-orange-500/10 flex items-center justify-center">
                            <AlertTriangle className="text-orange-400" size={16} />
                        </div>
                        <div>
                            <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Bounce Rate</p>
                            <p className="text-white font-black">2%</p>
                        </div>
                    </div>

                    <div className="bg-rvs-darker border border-rvs-steel/20 p-3 rounded-lg flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-rose-500/10 flex items-center justify-center">
                            <ShieldX className="text-rose-500" size={16} />
                        </div>
                        <div>
                            <p className="text-[10px] text-rvs-steel uppercase font-bold tracking-widest">Spam Block</p>
                            <p className="text-white font-black">0.5%</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="space-y-4">
                {sentMessages.map(msg => (
                    <div key={msg.id} className="bg-rvs-dark border border-rvs-steel/20 rounded-xl p-5 hover:border-rvs-steel/50 transition-all flex flex-col md:flex-row gap-6">

                        <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                                <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded ${msg.sender === 'AI' ? 'bg-rvs-red-dark/30 text-rvs-red-light' : 'bg-rvs-steel/20 text-rvs-chrome'}`}>
                                    Sent by {msg.sender}
                                </span>
                                <p className="text-sm font-bold text-white tracking-wide">{msg.to}</p>
                            </div>

                            <h3 className="text-lg font-black text-white mb-1">{msg.subject}</h3>
                            <p className="text-sm text-rvs-chrome truncate">{msg.content}</p>
                        </div>

                        <div className="md:w-64 flex flex-col justify-center space-y-3 bg-[#0A0A0A] border-l md:border-l border-t md:border-t-0 border-rvs-steel/10 pt-4 md:pt-0 md:pl-6">
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-rvs-steel flex items-center gap-2"><Check size={14} /> Sent</span>
                                <span className="text-white font-mono">{formatDate(msg.sentAt)}</span>
                            </div>

                            <div className="flex items-center justify-between text-xs">
                                <span className="flex items-center gap-2 text-rvs-steel">
                                    <CheckCheck size={14} className={msg.readAt ? "text-blue-400" : "text-rvs-steel/30"} />
                                    Opened
                                </span>
                                <span className={`font-mono ${msg.readAt ? 'text-blue-400 font-bold' : 'text-rvs-steel/50'}`}>
                                    {formatDate(msg.readAt)}
                                </span>
                            </div>

                            <div className="flex items-center justify-between text-xs">
                                <span className="flex items-center gap-2 text-rvs-steel">
                                    <MousePointerClick size={14} className={msg.clickedAt ? "text-rvs-red-light" : "text-rvs-steel/30"} />
                                    Clicked
                                </span>
                                <span className={`font-mono ${msg.clickedAt ? 'text-rvs-red-light font-bold' : 'text-rvs-steel/50'}`}>
                                    {formatDate(msg.clickedAt)}
                                </span>
                            </div>

                            {msg.repliedAt && (
                                <div className="flex items-center justify-between text-xs">
                                    <span className="flex items-center gap-2 text-rvs-steel">
                                        <Reply size={14} className="text-emerald-400" />
                                        Replied
                                    </span>
                                    <span className="font-mono text-emerald-400 font-bold">
                                        {formatDate(msg.repliedAt)}
                                    </span>
                                </div>
                            )}

                            {msg.bouncedAt && (
                                <div className="flex items-center justify-between text-xs">
                                    <span className="flex items-center gap-2 text-rvs-steel">
                                        <AlertTriangle size={14} className="text-orange-400" />
                                        Bounced
                                    </span>
                                    <span className="font-mono text-orange-400 font-bold">
                                        {formatDate(msg.bouncedAt)}
                                    </span>
                                </div>
                            )}

                            {msg.spamAt && (
                                <div className="flex items-center justify-between text-xs">
                                    <span className="flex items-center gap-2 text-rvs-steel">
                                        <ShieldX size={14} className="text-rose-500" />
                                        Spam Block
                                    </span>
                                    <span className="font-mono text-rose-500 font-bold">
                                        {formatDate(msg.spamAt)}
                                    </span>
                                </div>
                            )}
                        </div>

                    </div>
                ))}
            </div>

        </div>
    );
}
